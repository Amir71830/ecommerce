const String emptyCartLottie =
    "https://assets1.lottiefiles.com/packages/lf20_qh5z2fdq.json";
const String locationLottie =
    "https://assets5.lottiefiles.com/packages/lf20_UgZWvP.json";
const String contentImage = "assets/Img/content.png";
const String aboutImage = "assets/Img/about.png";
const String manImage = "assets/Img/man.png";
const String searchLottie =
    "https://assets2.lottiefiles.com/packages/lf20_LKXG6QRgtE.json";
const String loginLottie =
    "https://assets3.lottiefiles.com/packages/lf20_KvK0ZJBQzu.json";

const String emtySearchLottie =
    "https://assets9.lottiefiles.com/packages/lf20_wnqlfojb.json";

const String developerGithub = "https://github.com/EmirBashiri";

const String emptyListLottie =
    "https://assets10.lottiefiles.com/packages/lf20_ysrn2iwp.json";
